package com.bcipriano.codeGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
